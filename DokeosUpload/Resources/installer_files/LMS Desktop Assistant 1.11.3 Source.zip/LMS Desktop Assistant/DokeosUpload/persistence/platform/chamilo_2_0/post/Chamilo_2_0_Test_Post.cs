﻿/*
*  
*  Copyright (C) 2010-2011 University College Ghent.
*  
*  For a full list of contributors, see "credits.txt".
*  
*  This file is part of LMS Desktop Assistant.
*  
*  LMS Desktop Assistant is free software: you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*  
*  LMS Desktop Assistant is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with LMS Desktop Assistant. If not, see <http://www.gnu.org/licenses/>.
*  
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using lmsda.domain.user;
using lmsda.domain.exercise;
using lmsda.persistence.httpcommunication;
using lmsda.domain;
using lmsda.domain.score;
using System.Xml;
using lmsda.domain.util.xml;
using lmsda.domain.util;
using System.IO;
using lmsda.persistence.platform.chamilo_2_0;
using lmsda.domain.score.data;
using System.Text.RegularExpressions;

namespace lmsda.persistence.platform.chamilo_2_0.post
{
    /// <summary>
    ///     This class is a compatibility implementation for Chamilo 2.0 without regex support
    ///     in the Fill in the Gaps exercises. It should only be used for the in-between phase.
    /// </summary>
    class Chamilo_2_0_Test_Post : Chamilo_2_0_Post
    {

        protected override TargetPlatformInfo getPlatformInfo()
        {
            return new Chamilo_2_0_Test_PlatformInfo();
        }

        /// <summary>
        ///     Instantiates a new Chamilo 2.0 (POST) object.
        /// </summary>
        /// <param name="login">The login information.</param>
        public Chamilo_2_0_Test_Post(Login login) : base(login)
        {
        }

        /// <summary>
        ///     Adds gaps answers to a question.
        ///     This function is an override with support for Chamilo 2.0 platforms without the
        ///     new advanced options, like regex support and configurable default scores.
        /// </summary>
        /// <param name="question">The question.</param>
        /// <param name="httpSession">The working session.</param>
        /// <returns>The question's weight</returns>
        protected override int addAnswersGaps(HttpSession httpSession, Question question)
        {
            const String gapsRegex = @"\[([^\[\]]+)\]";
            const String regexStart = "{regex(?:=[0-9]+)?}";
            const String regexEnd = "{/regex}$";
            const String regexMatches = regexStart + "(.*?)" + regexEnd;
            int defaultScore = 1;

            const char separator = ',';
            int totalweight = 0;
            Answer[] answers = question.getAnswersAsArray();
            String answer = answers[0].getAnswer();
            Regex gaps = new Regex(gapsRegex);
            Regex regex = new Regex(regexMatches);
            Match matcher = gaps.Match(answer);
            int answernumber = -1;
            String repl;
            int indexcorrection = 0;
            while (matcher.Success)
            {
                repl = String.Empty;
                answernumber++;
                if (answernumber < answers.Length)
                {
                    String feedback = answers[answernumber].getFeedback();
                    int weight = answers[answernumber].getWeight();
                    totalweight += weight;
                    if (feedback == null) feedback = String.Empty;
                    String answerText = matcher.Groups[1].Value;
                    Match regexMatch = regex.Match(answerText);
                    String[] gappossibilities;
                    if (regexMatch.Success)
                    {
                        answerText = Regex.Replace(answerText, regexStart, "{regex}");
                        const String multipleRegex = "{/regex}|{regex}";
                        if (answerText.IndexOf(multipleRegex) != -1)
                        {
                            answerText = answerText.Replace("{regex}/", String.Empty);
                            answerText = answerText.Replace("/i{/regex}", String.Empty);
                            answerText = answerText.Replace("{regex}", String.Empty);
                            answerText = answerText.Replace("{/regex}", String.Empty);
                        }
                    }
                    if (answerText.Contains('|'))                       
                        gappossibilities = answerText.Split('|');
                    else
                        gappossibilities = new String[] { answerText };

                    // [antwoord_1|antwoord_2] ==>
                    // [antwoord_1(feedback)=score,antwoord_2(feedback)=score]
                    foreach (String gappossib in gappossibilities)
                    {
                        String gappossibility = gappossib;
                        if (regexMatch.Success)
                        {
                            if (gappossibility.Length > 0)
                            {
                                if (gappossibility[0] == '^')
                                    gappossibility = gappossibility.Substring(1);
                                if (gappossibility[gappossibility.Length - 1] == '$')
                                    gappossibility = gappossibility.Substring(0, gappossibility.Length - 1);
                            }
                        }
                        repl += gappossibility;
                        if (!feedback.Equals(String.Empty))
                            repl += "(" + feedback + ")";
                        if (weight != defaultScore)
                            repl += "=" + weight;
                        repl += separator;
                    }
                    repl = repl.TrimEnd(separator);
                    answer = answer.Substring(0, matcher.Groups[1].Index + indexcorrection) + repl + answer.Substring(matcher.Groups[1].Index + matcher.Groups[1].Length + indexcorrection);
                    indexcorrection += repl.Length - matcher.Groups[1].Length;
                }
                matcher = matcher.NextMatch();
            }
            httpSession.addNameValuePair("question_type", "0");
            httpSession.addNameValuePair("default_positive_score", defaultScore.ToString());
            httpSession.addNameValuePair("default_negative_score", "0");
            httpSession.addNameValuePair("field_option_variation", "3");
            httpSession.addNameValuePair("uniform_input_type", "0");
            httpSession.addNameValuePair("field_option_size", "15");
            httpSession.addNameValuePair("case_sensitive", "1");
            httpSession.addNameValuePair("show_inline", "1");
            httpSession.addNameValuePair("answer_text", answer);
            httpSession.addNameValuePair("answer", answer);
            return totalweight;
        }


    }
}
