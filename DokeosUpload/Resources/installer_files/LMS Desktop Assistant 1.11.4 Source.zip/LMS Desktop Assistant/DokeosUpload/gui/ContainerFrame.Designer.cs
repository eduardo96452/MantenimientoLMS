﻿/*
*  
*  Copyright (C) 2010-2011 University College Ghent.
*  
*  For a full list of contributors, see "credits.txt".
*  
*  This file is part of LMS Desktop Assistant.
*  
*  LMS Desktop Assistant is free software: you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*  
*  LMS Desktop Assistant is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with LMS Desktop Assistant. If not, see <http://www.gnu.org/licenses/>.
*  
*/

namespace lmsda.gui
{
    partial class ContainerFrame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.txtExerciseDump = new System.Windows.Forms.TextBox();
            this.cmdScanDocument = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.grbLogin = new System.Windows.Forms.GroupBox();
            this.cmdLogin = new System.Windows.Forms.Button();
            this.cmbCourses = new System.Windows.Forms.ComboBox();
            this.lblInformation = new System.Windows.Forms.Label();
            this.cmdLogout = new System.Windows.Forms.Button();
            this.menuBar = new System.Windows.Forms.MenuStrip();
            this.actionsMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.uploadfilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.viewlogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.preferencesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageSubjectsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.checkforupdatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabs = new System.Windows.Forms.TabControl();
            this.tabExercises = new System.Windows.Forms.TabPage();
            this.nrRandomQuestions = new System.Windows.Forms.NumericUpDown();
            this.chkRandomQuestions = new System.Windows.Forms.CheckBox();
            this.lblTreeEx04 = new System.Windows.Forms.Label();
            this.lblTreeEx03 = new System.Windows.Forms.Label();
            this.chkSetExerciseInvisible = new System.Windows.Forms.CheckBox();
            this.lblExerciseScanResultsDump = new System.Windows.Forms.Label();
            this.lblExerciseScanResults = new System.Windows.Forms.Label();
            this.lblExerciseErrors = new System.Windows.Forms.Label();
            this.lblTreeEx02 = new System.Windows.Forms.Label();
            this.chkOneQuestionPerPage = new System.Windows.Forms.CheckBox();
            this.lblTreeEx01 = new System.Windows.Forms.Label();
            this.chkNewDocWithExamples = new System.Windows.Forms.CheckBox();
            this.cmdOpenTemplate = new System.Windows.Forms.Button();
            this.cmdReviewExercises = new System.Windows.Forms.Button();
            this.cmdUploadExercises = new System.Windows.Forms.Button();
            this.cmdJumpToError = new System.Windows.Forms.Button();
            this.tabPDF = new System.Windows.Forms.TabPage();
            this.chkConvertHyperlinksToJavascript = new System.Windows.Forms.CheckBox();
            this.lblTreePdf02 = new System.Windows.Forms.Label();
            this.lblTreePdf01 = new System.Windows.Forms.Label();
            this.rdbPerStyle = new System.Windows.Forms.RadioButton();
            this.rdbPerPage = new System.Windows.Forms.RadioButton();
            this.chkUpload = new System.Windows.Forms.CheckBox();
            this.txtSplit = new System.Windows.Forms.TextBox();
            this.chkSplit = new System.Windows.Forms.CheckBox();
            this.cmdConvertToPDF = new System.Windows.Forms.Button();
            this.documentsDropDownForPDF = new lmsda.gui.DocumentsDropDown();
            this.tabStatistics = new System.Windows.Forms.TabPage();
            this.chkGroups = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lstGroups = new lmsda.gui.listview.DragAndDropListView();
            this.label2 = new System.Windows.Forms.Label();
            this.lstColumns = new lmsda.gui.listview.DragAndDropListView();
            this.lblColumns = new System.Windows.Forms.Label();
            this.chkGenerateAllAttempts = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkOpenExcelFilesAfterConversion = new System.Windows.Forms.CheckBox();
            this.chkStatisticsCreateSubFolder = new System.Windows.Forms.CheckBox();
            this.chkCalculateExerciseStudentDetails = new System.Windows.Forms.CheckBox();
            this.chkCalculateResultsPerStudent = new System.Windows.Forms.CheckBox();
            this.lblTreeStat03 = new System.Windows.Forms.Label();
            this.lblTreeStat02 = new System.Windows.Forms.Label();
            this.chkCalculatePercentageMC = new System.Windows.Forms.CheckBox();
            this.chkCPMCShowQuestionTitles = new System.Windows.Forms.CheckBox();
            this.txtDoNotKnow = new System.Windows.Forms.TextBox();
            this.lblDoNotKnow = new System.Windows.Forms.Label();
            this.cmdDownloadStatistics = new System.Windows.Forms.Button();
            this.tabSynchronization = new System.Windows.Forms.TabPage();
            this.tableLayoutStartSync = new System.Windows.Forms.TableLayoutPanel();
            this.lblSynchronisationStatus = new System.Windows.Forms.Label();
            this.pnlSyncButtons = new System.Windows.Forms.Panel();
            this.cmdStartSynchronization = new System.Windows.Forms.Button();
            this.cmdStopSynchronization = new System.Windows.Forms.Button();
            this.progressBarSyncTotal = new System.Windows.Forms.ProgressBar();
            this.subjectFilesSettingsControl = new lmsda.gui.subject.SubjectFilesSettingsControl();
            this.cmdChooseDocument = new System.Windows.Forms.Button();
            this.grbDocument = new System.Windows.Forms.GroupBox();
            this.lblDocumentSelected = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.lblStatus = new System.Windows.Forms.Label();
            this.grbLogin.SuspendLayout();
            this.menuBar.SuspendLayout();
            this.tabs.SuspendLayout();
            this.tabExercises.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrRandomQuestions)).BeginInit();
            this.tabPDF.SuspendLayout();
            this.tabStatistics.SuspendLayout();
            this.tabSynchronization.SuspendLayout();
            this.tableLayoutStartSync.SuspendLayout();
            this.pnlSyncButtons.SuspendLayout();
            this.grbDocument.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.AcceptsReturn = true;
            this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLog.HideSelection = false;
            this.txtLog.Location = new System.Drawing.Point(93, 523);
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.Size = new System.Drawing.Size(700, 20);
            this.txtLog.TabIndex = 5;
            this.txtLog.TabStop = false;
            this.txtLog.DoubleClick += new System.EventHandler(this.txtLog_DoubleClick);
            // 
            // txtExerciseDump
            // 
            this.txtExerciseDump.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExerciseDump.BackColor = System.Drawing.Color.White;
            this.txtExerciseDump.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.txtExerciseDump.Location = new System.Drawing.Point(228, 119);
            this.txtExerciseDump.Multiline = true;
            this.txtExerciseDump.Name = "txtExerciseDump";
            this.txtExerciseDump.ReadOnly = true;
            this.txtExerciseDump.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtExerciseDump.Size = new System.Drawing.Size(525, 239);
            this.txtExerciseDump.TabIndex = 6;
            this.txtExerciseDump.TabStop = false;
            // 
            // cmdScanDocument
            // 
            this.cmdScanDocument.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdScanDocument.Location = new System.Drawing.Point(6, 119);
            this.cmdScanDocument.Name = "cmdScanDocument";
            this.cmdScanDocument.Size = new System.Drawing.Size(205, 23);
            this.cmdScanDocument.TabIndex = 5;
            this.cmdScanDocument.Tag = "scan_document";
            this.cmdScanDocument.Text = "scan_document";
            this.cmdScanDocument.UseVisualStyleBackColor = true;
            this.cmdScanDocument.Click += new System.EventHandler(this.cmdScanDocument_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            this.openFileDialog.Filter = "Word 2007 files|*.docx";
            // 
            // grbLogin
            // 
            this.grbLogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbLogin.Controls.Add(this.cmdLogin);
            this.grbLogin.Controls.Add(this.cmbCourses);
            this.grbLogin.Controls.Add(this.lblInformation);
            this.grbLogin.Controls.Add(this.cmdLogout);
            this.grbLogin.Location = new System.Drawing.Point(12, 27);
            this.grbLogin.Name = "grbLogin";
            this.grbLogin.Size = new System.Drawing.Size(768, 41);
            this.grbLogin.TabIndex = 9;
            this.grbLogin.TabStop = false;
            // 
            // cmdLogin
            // 
            this.cmdLogin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdLogin.Location = new System.Drawing.Point(6, 11);
            this.cmdLogin.Name = "cmdLogin";
            this.cmdLogin.Size = new System.Drawing.Size(121, 23);
            this.cmdLogin.TabIndex = 1;
            this.cmdLogin.Tag = "login";
            this.cmdLogin.Text = "login";
            this.cmdLogin.UseVisualStyleBackColor = true;
            this.cmdLogin.Click += new System.EventHandler(this.cmdLogin_Click);
            // 
            // cmbCourses
            // 
            this.cmbCourses.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbCourses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCourses.FormattingEnabled = true;
            this.cmbCourses.Location = new System.Drawing.Point(449, 13);
            this.cmbCourses.Name = "cmbCourses";
            this.cmbCourses.Size = new System.Drawing.Size(313, 21);
            this.cmbCourses.TabIndex = 2;
            this.cmbCourses.SelectedIndexChanged += new System.EventHandler(this.cmbCourses_SelectedIndexChanged);
            // 
            // lblInformation
            // 
            this.lblInformation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInformation.AutoSize = true;
            this.lblInformation.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblInformation.Location = new System.Drawing.Point(133, 16);
            this.lblInformation.Name = "lblInformation";
            this.lblInformation.Size = new System.Drawing.Size(141, 13);
            this.lblInformation.TabIndex = 0;
            this.lblInformation.Text = "login information comes here";
            // 
            // cmdLogout
            // 
            this.cmdLogout.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdLogout.Location = new System.Drawing.Point(6, 11);
            this.cmdLogout.Name = "cmdLogout";
            this.cmdLogout.Size = new System.Drawing.Size(120, 23);
            this.cmdLogout.TabIndex = 1;
            this.cmdLogout.Tag = "logout";
            this.cmdLogout.Text = "logout";
            this.cmdLogout.UseVisualStyleBackColor = true;
            this.cmdLogout.Visible = false;
            this.cmdLogout.Click += new System.EventHandler(this.cmdLogout_Click);
            // 
            // menuBar
            // 
            this.menuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.actionsMenuToolStripMenuItem,
            this.editMenuToolStripMenuItem,
            this.helpMenuToolStripMenuItem});
            this.menuBar.Location = new System.Drawing.Point(0, 0);
            this.menuBar.Name = "menuBar";
            this.menuBar.Size = new System.Drawing.Size(792, 24);
            this.menuBar.TabIndex = 10;
            this.menuBar.Text = "menuBar";
            // 
            // actionsMenuToolStripMenuItem
            // 
            this.actionsMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.aToolStripMenuItem,
            this.uploadfilesToolStripMenuItem,
            this.toolStripSeparator2,
            this.viewlogToolStripMenuItem,
            this.tToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.actionsMenuToolStripMenuItem.Name = "actionsMenuToolStripMenuItem";
            this.actionsMenuToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.actionsMenuToolStripMenuItem.Tag = "menu_actions";
            this.actionsMenuToolStripMenuItem.Text = "menu_actions";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.loginToolStripMenuItem.Tag = "menu_login";
            this.loginToolStripMenuItem.Text = "menu_login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Enabled = false;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.logoutToolStripMenuItem.Tag = "menu_logout";
            this.logoutToolStripMenuItem.Text = "menu_logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(144, 6);
            // 
            // uploadfilesToolStripMenuItem
            // 
            this.uploadfilesToolStripMenuItem.Enabled = false;
            this.uploadfilesToolStripMenuItem.Name = "uploadfilesToolStripMenuItem";
            this.uploadfilesToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.uploadfilesToolStripMenuItem.Tag = "upload_files";
            this.uploadfilesToolStripMenuItem.Text = "upload_files";
            this.uploadfilesToolStripMenuItem.Click += new System.EventHandler(this.uploadfilesToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(144, 6);
            // 
            // viewlogToolStripMenuItem
            // 
            this.viewlogToolStripMenuItem.Name = "viewlogToolStripMenuItem";
            this.viewlogToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.viewlogToolStripMenuItem.Tag = "view_log";
            this.viewlogToolStripMenuItem.Text = "view_log";
            this.viewlogToolStripMenuItem.Click += new System.EventHandler(this.viewlogToolStripMenuItem_Click);
            // 
            // tToolStripMenuItem
            // 
            this.tToolStripMenuItem.Name = "tToolStripMenuItem";
            this.tToolStripMenuItem.Size = new System.Drawing.Size(144, 6);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.quitToolStripMenuItem.Tag = "menu_quit";
            this.quitToolStripMenuItem.Text = "menu_quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // editMenuToolStripMenuItem
            // 
            this.editMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.preferencesToolStripMenuItem,
            this.manageSubjectsToolStripMenuItem});
            this.editMenuToolStripMenuItem.Name = "editMenuToolStripMenuItem";
            this.editMenuToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.editMenuToolStripMenuItem.Tag = "menu_edit";
            this.editMenuToolStripMenuItem.Text = "menu_edit";
            // 
            // preferencesToolStripMenuItem
            // 
            this.preferencesToolStripMenuItem.Name = "preferencesToolStripMenuItem";
            this.preferencesToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.preferencesToolStripMenuItem.Tag = "menu_preferences";
            this.preferencesToolStripMenuItem.Text = "menu_preferences";
            this.preferencesToolStripMenuItem.Click += new System.EventHandler(this.preferencesToolStripMenuItem_Click);
            // 
            // manageSubjectsToolStripMenuItem
            // 
            this.manageSubjectsToolStripMenuItem.Name = "manageSubjectsToolStripMenuItem";
            this.manageSubjectsToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.manageSubjectsToolStripMenuItem.Tag = "menu_manage_subjects";
            this.manageSubjectsToolStripMenuItem.Text = "menu_manage_subjects";
            this.manageSubjectsToolStripMenuItem.Click += new System.EventHandler(this.manageSubjectsToolStripMenuItem_Click);
            // 
            // helpMenuToolStripMenuItem
            // 
            this.helpMenuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem,
            this.toolStripSeparator1,
            this.checkforupdatesToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.helpMenuToolStripMenuItem.Name = "helpMenuToolStripMenuItem";
            this.helpMenuToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.helpMenuToolStripMenuItem.Tag = "menu_help";
            this.helpMenuToolStripMenuItem.Text = "menu_help";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.helpToolStripMenuItem.Tag = "menu_help";
            this.helpToolStripMenuItem.Text = "menu_help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(206, 6);
            // 
            // checkforupdatesToolStripMenuItem
            // 
            this.checkforupdatesToolStripMenuItem.Name = "checkforupdatesToolStripMenuItem";
            this.checkforupdatesToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.checkforupdatesToolStripMenuItem.Tag = "menu_check_for_updates";
            this.checkforupdatesToolStripMenuItem.Text = "menu_check_for_updates";
            this.checkforupdatesToolStripMenuItem.Click += new System.EventHandler(this.checkforupdatesToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.aboutToolStripMenuItem.Tag = "menu_about";
            this.aboutToolStripMenuItem.Text = "menu_about";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // tabs
            // 
            this.tabs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabs.Controls.Add(this.tabExercises);
            this.tabs.Controls.Add(this.tabPDF);
            this.tabs.Controls.Add(this.tabStatistics);
            this.tabs.Controls.Add(this.tabSynchronization);
            this.tabs.Location = new System.Drawing.Point(13, 121);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(767, 390);
            this.tabs.TabIndex = 4;
            this.tabs.SelectedIndexChanged += new System.EventHandler(this.tabs_SelectedIndexChanged);
            this.tabs.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabs_Selecting);
            // 
            // tabExercises
            // 
            this.tabExercises.Controls.Add(this.nrRandomQuestions);
            this.tabExercises.Controls.Add(this.chkRandomQuestions);
            this.tabExercises.Controls.Add(this.lblTreeEx04);
            this.tabExercises.Controls.Add(this.lblTreeEx03);
            this.tabExercises.Controls.Add(this.chkSetExerciseInvisible);
            this.tabExercises.Controls.Add(this.lblExerciseScanResultsDump);
            this.tabExercises.Controls.Add(this.lblExerciseScanResults);
            this.tabExercises.Controls.Add(this.lblExerciseErrors);
            this.tabExercises.Controls.Add(this.lblTreeEx02);
            this.tabExercises.Controls.Add(this.chkOneQuestionPerPage);
            this.tabExercises.Controls.Add(this.lblTreeEx01);
            this.tabExercises.Controls.Add(this.chkNewDocWithExamples);
            this.tabExercises.Controls.Add(this.cmdOpenTemplate);
            this.tabExercises.Controls.Add(this.cmdReviewExercises);
            this.tabExercises.Controls.Add(this.cmdUploadExercises);
            this.tabExercises.Controls.Add(this.txtExerciseDump);
            this.tabExercises.Controls.Add(this.cmdScanDocument);
            this.tabExercises.Controls.Add(this.cmdJumpToError);
            this.tabExercises.Location = new System.Drawing.Point(4, 22);
            this.tabExercises.Name = "tabExercises";
            this.tabExercises.Padding = new System.Windows.Forms.Padding(3);
            this.tabExercises.Size = new System.Drawing.Size(759, 364);
            this.tabExercises.TabIndex = 0;
            this.tabExercises.Tag = "exercises";
            this.tabExercises.Text = "exercises";
            this.tabExercises.UseVisualStyleBackColor = true;
            this.tabExercises.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tabExercises_MouseMove);
            // 
            // nrRandomQuestions
            // 
            this.nrRandomQuestions.Location = new System.Drawing.Point(76, 317);
            this.nrRandomQuestions.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nrRandomQuestions.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nrRandomQuestions.Name = "nrRandomQuestions";
            this.nrRandomQuestions.Size = new System.Drawing.Size(120, 20);
            this.nrRandomQuestions.TabIndex = 45;
            this.nrRandomQuestions.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nrRandomQuestions.Visible = false;
            // 
            // chkRandomQuestions
            // 
            this.chkRandomQuestions.AutoSize = true;
            this.chkRandomQuestions.Location = new System.Drawing.Point(27, 294);
            this.chkRandomQuestions.Name = "chkRandomQuestions";
            this.chkRandomQuestions.Size = new System.Drawing.Size(135, 17);
            this.chkRandomQuestions.TabIndex = 44;
            this.chkRandomQuestions.Tag = "use_random_questions";
            this.chkRandomQuestions.Text = "use_random_questions";
            this.chkRandomQuestions.UseVisualStyleBackColor = true;
            this.chkRandomQuestions.CheckedChanged += new System.EventHandler(this.chkRandomQuestions_CheckedChanged);
            // 
            // lblTreeEx04
            // 
            this.lblTreeEx04.AutoSize = true;
            this.lblTreeEx04.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeEx04.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeEx04.Location = new System.Drawing.Point(12, 295);
            this.lblTreeEx04.Name = "lblTreeEx04";
            this.lblTreeEx04.Size = new System.Drawing.Size(10, 13);
            this.lblTreeEx04.TabIndex = 41;
            this.lblTreeEx04.Text = " ";
            // 
            // lblTreeEx03
            // 
            this.lblTreeEx03.AutoSize = true;
            this.lblTreeEx03.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeEx03.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeEx03.Location = new System.Drawing.Point(12, 259);
            this.lblTreeEx03.Name = "lblTreeEx03";
            this.lblTreeEx03.Size = new System.Drawing.Size(10, 13);
            this.lblTreeEx03.TabIndex = 41;
            this.lblTreeEx03.Text = " ";
            // 
            // chkSetExerciseInvisible
            // 
            this.chkSetExerciseInvisible.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkSetExerciseInvisible.Location = new System.Drawing.Point(27, 258);
            this.chkSetExerciseInvisible.Name = "chkSetExerciseInvisible";
            this.chkSetExerciseInvisible.Size = new System.Drawing.Size(184, 30);
            this.chkSetExerciseInvisible.TabIndex = 40;
            this.chkSetExerciseInvisible.Tag = "set_exercises_invisible";
            this.chkSetExerciseInvisible.Text = "set_exercises_invisible";
            this.chkSetExerciseInvisible.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkSetExerciseInvisible.UseVisualStyleBackColor = true;
            // 
            // lblExerciseScanResultsDump
            // 
            this.lblExerciseScanResultsDump.Location = new System.Drawing.Point(243, 32);
            this.lblExerciseScanResultsDump.Name = "lblExerciseScanResultsDump";
            this.lblExerciseScanResultsDump.Size = new System.Drawing.Size(203, 58);
            this.lblExerciseScanResultsDump.TabIndex = 39;
            this.lblExerciseScanResultsDump.Text = "exercises: x\r\nquestions: x\r\nerrors: x:\r\nwarnings: x";
            // 
            // lblExerciseScanResults
            // 
            this.lblExerciseScanResults.AutoSize = true;
            this.lblExerciseScanResults.Location = new System.Drawing.Point(225, 13);
            this.lblExerciseScanResults.Name = "lblExerciseScanResults";
            this.lblExerciseScanResults.Size = new System.Drawing.Size(72, 13);
            this.lblExerciseScanResults.TabIndex = 38;
            this.lblExerciseScanResults.Tag = "scan_results :";
            this.lblExerciseScanResults.Text = "scan_results :";
            // 
            // lblExerciseErrors
            // 
            this.lblExerciseErrors.AutoSize = true;
            this.lblExerciseErrors.Location = new System.Drawing.Point(225, 95);
            this.lblExerciseErrors.Name = "lblExerciseErrors";
            this.lblExerciseErrors.Size = new System.Drawing.Size(111, 13);
            this.lblExerciseErrors.TabIndex = 37;
            this.lblExerciseErrors.Tag = "errors_and_warnings :";
            this.lblExerciseErrors.Text = "errors_and_warnings :";
            // 
            // lblTreeEx02
            // 
            this.lblTreeEx02.AutoSize = true;
            this.lblTreeEx02.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeEx02.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeEx02.Location = new System.Drawing.Point(12, 236);
            this.lblTreeEx02.Name = "lblTreeEx02";
            this.lblTreeEx02.Size = new System.Drawing.Size(10, 13);
            this.lblTreeEx02.TabIndex = 36;
            this.lblTreeEx02.Text = " ";
            // 
            // chkOneQuestionPerPage
            // 
            this.chkOneQuestionPerPage.AutoSize = true;
            this.chkOneQuestionPerPage.Location = new System.Drawing.Point(27, 235);
            this.chkOneQuestionPerPage.Name = "chkOneQuestionPerPage";
            this.chkOneQuestionPerPage.Size = new System.Drawing.Size(141, 17);
            this.chkOneQuestionPerPage.TabIndex = 11;
            this.chkOneQuestionPerPage.Tag = "one_question_per_page";
            this.chkOneQuestionPerPage.Text = "one_question_per_page";
            this.chkOneQuestionPerPage.UseVisualStyleBackColor = true;
            this.chkOneQuestionPerPage.CheckedChanged += new System.EventHandler(this.chkOneQuestionPerPage_CheckedChanged);
            // 
            // lblTreeEx01
            // 
            this.lblTreeEx01.AutoSize = true;
            this.lblTreeEx01.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeEx01.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeEx01.Location = new System.Drawing.Point(12, 38);
            this.lblTreeEx01.Name = "lblTreeEx01";
            this.lblTreeEx01.Size = new System.Drawing.Size(10, 13);
            this.lblTreeEx01.TabIndex = 35;
            this.lblTreeEx01.Text = " ";
            // 
            // chkNewDocWithExamples
            // 
            this.chkNewDocWithExamples.AutoSize = true;
            this.chkNewDocWithExamples.Location = new System.Drawing.Point(27, 37);
            this.chkNewDocWithExamples.Name = "chkNewDocWithExamples";
            this.chkNewDocWithExamples.Size = new System.Drawing.Size(145, 17);
            this.chkNewDocWithExamples.TabIndex = 12;
            this.chkNewDocWithExamples.Tag = "new_doc_with_examples";
            this.chkNewDocWithExamples.Text = "new_doc_with_examples";
            this.chkNewDocWithExamples.UseVisualStyleBackColor = true;
            // 
            // cmdOpenTemplate
            // 
            this.cmdOpenTemplate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdOpenTemplate.Location = new System.Drawing.Point(6, 8);
            this.cmdOpenTemplate.Name = "cmdOpenTemplate";
            this.cmdOpenTemplate.Size = new System.Drawing.Size(205, 23);
            this.cmdOpenTemplate.TabIndex = 11;
            this.cmdOpenTemplate.Tag = "new_from_template";
            this.cmdOpenTemplate.Text = "new_from_template";
            this.cmdOpenTemplate.UseVisualStyleBackColor = true;
            this.cmdOpenTemplate.Click += new System.EventHandler(this.cmdOpenTemplate_Click);
            // 
            // cmdReviewExercises
            // 
            this.cmdReviewExercises.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdReviewExercises.Location = new System.Drawing.Point(6, 148);
            this.cmdReviewExercises.Name = "cmdReviewExercises";
            this.cmdReviewExercises.Size = new System.Drawing.Size(205, 23);
            this.cmdReviewExercises.TabIndex = 6;
            this.cmdReviewExercises.Tag = "review_exercises";
            this.cmdReviewExercises.Text = "review_exercises";
            this.cmdReviewExercises.UseVisualStyleBackColor = true;
            this.cmdReviewExercises.Click += new System.EventHandler(this.cmdReviewExercises_Click);
            // 
            // cmdUploadExercises
            // 
            this.cmdUploadExercises.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdUploadExercises.Location = new System.Drawing.Point(6, 206);
            this.cmdUploadExercises.Name = "cmdUploadExercises";
            this.cmdUploadExercises.Size = new System.Drawing.Size(205, 23);
            this.cmdUploadExercises.TabIndex = 8;
            this.cmdUploadExercises.Tag = "upload_exercises";
            this.cmdUploadExercises.Text = "upload_exercises";
            this.cmdUploadExercises.UseVisualStyleBackColor = true;
            this.cmdUploadExercises.Click += new System.EventHandler(this.cmdUploadExercises_Click);
            // 
            // cmdJumpToError
            // 
            this.cmdJumpToError.Location = new System.Drawing.Point(6, 177);
            this.cmdJumpToError.Name = "cmdJumpToError";
            this.cmdJumpToError.Size = new System.Drawing.Size(205, 23);
            this.cmdJumpToError.TabIndex = 7;
            this.cmdJumpToError.Tag = "jump_to_error";
            this.cmdJumpToError.Text = "jump_to_error";
            this.cmdJumpToError.UseVisualStyleBackColor = true;
            this.cmdJumpToError.Click += new System.EventHandler(this.cmdJumpToError_Click);
            // 
            // tabPDF
            // 
            this.tabPDF.Controls.Add(this.chkConvertHyperlinksToJavascript);
            this.tabPDF.Controls.Add(this.lblTreePdf02);
            this.tabPDF.Controls.Add(this.lblTreePdf01);
            this.tabPDF.Controls.Add(this.rdbPerStyle);
            this.tabPDF.Controls.Add(this.rdbPerPage);
            this.tabPDF.Controls.Add(this.chkUpload);
            this.tabPDF.Controls.Add(this.txtSplit);
            this.tabPDF.Controls.Add(this.chkSplit);
            this.tabPDF.Controls.Add(this.cmdConvertToPDF);
            this.tabPDF.Controls.Add(this.documentsDropDownForPDF);
            this.tabPDF.Location = new System.Drawing.Point(4, 22);
            this.tabPDF.Name = "tabPDF";
            this.tabPDF.Padding = new System.Windows.Forms.Padding(3);
            this.tabPDF.Size = new System.Drawing.Size(759, 364);
            this.tabPDF.TabIndex = 1;
            this.tabPDF.Tag = "pdf_conversion";
            this.tabPDF.Text = "pdf_conversion";
            this.tabPDF.UseVisualStyleBackColor = true;
            this.tabPDF.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tabPDF_MouseMove);
            // 
            // chkConvertHyperlinksToJavascript
            // 
            this.chkConvertHyperlinksToJavascript.AutoSize = true;
            this.chkConvertHyperlinksToJavascript.Location = new System.Drawing.Point(15, 127);
            this.chkConvertHyperlinksToJavascript.Name = "chkConvertHyperlinksToJavascript";
            this.chkConvertHyperlinksToJavascript.Size = new System.Drawing.Size(181, 17);
            this.chkConvertHyperlinksToJavascript.TabIndex = 36;
            this.chkConvertHyperlinksToJavascript.Tag = "convert_hyperlinks_to_javascript";
            this.chkConvertHyperlinksToJavascript.Text = "convert_hyperlinks_to_javascript";
            this.chkConvertHyperlinksToJavascript.UseVisualStyleBackColor = true;
            // 
            // lblTreePdf02
            // 
            this.lblTreePdf02.AutoSize = true;
            this.lblTreePdf02.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreePdf02.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreePdf02.Location = new System.Drawing.Point(34, 64);
            this.lblTreePdf02.Name = "lblTreePdf02";
            this.lblTreePdf02.Size = new System.Drawing.Size(10, 13);
            this.lblTreePdf02.TabIndex = 35;
            this.lblTreePdf02.Text = " ";
            // 
            // lblTreePdf01
            // 
            this.lblTreePdf01.AutoSize = true;
            this.lblTreePdf01.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreePdf01.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreePdf01.Location = new System.Drawing.Point(34, 41);
            this.lblTreePdf01.Name = "lblTreePdf01";
            this.lblTreePdf01.Size = new System.Drawing.Size(10, 13);
            this.lblTreePdf01.TabIndex = 34;
            this.lblTreePdf01.Text = " ";
            // 
            // rdbPerStyle
            // 
            this.rdbPerStyle.AutoSize = true;
            this.rdbPerStyle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rdbPerStyle.Location = new System.Drawing.Point(54, 62);
            this.rdbPerStyle.Name = "rdbPerStyle";
            this.rdbPerStyle.Size = new System.Drawing.Size(181, 17);
            this.rdbPerStyle.TabIndex = 9;
            this.rdbPerStyle.Tag = "split_per_style_restart_numbering";
            this.rdbPerStyle.Text = "split_per_style_restart_numbering";
            this.rdbPerStyle.UseVisualStyleBackColor = true;
            // 
            // rdbPerPage
            // 
            this.rdbPerPage.AutoSize = true;
            this.rdbPerPage.Checked = true;
            this.rdbPerPage.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rdbPerPage.Location = new System.Drawing.Point(54, 39);
            this.rdbPerPage.Name = "rdbPerPage";
            this.rdbPerPage.Size = new System.Drawing.Size(94, 17);
            this.rdbPerPage.TabIndex = 8;
            this.rdbPerPage.TabStop = true;
            this.rdbPerPage.Tag = "split_per_page";
            this.rdbPerPage.Text = "split_per_page";
            this.rdbPerPage.UseVisualStyleBackColor = true;
            // 
            // chkUpload
            // 
            this.chkUpload.AutoSize = true;
            this.chkUpload.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.chkUpload.Location = new System.Drawing.Point(15, 93);
            this.chkUpload.Name = "chkUpload";
            this.chkUpload.Size = new System.Drawing.Size(163, 17);
            this.chkUpload.TabIndex = 10;
            this.chkUpload.Tag = "upload_to_documents_folder";
            this.chkUpload.Text = "upload_to_documents_folder";
            this.chkUpload.UseVisualStyleBackColor = true;
            this.chkUpload.CheckedChanged += new System.EventHandler(this.chkUpload_CheckedChanged);
            // 
            // txtSplit
            // 
            this.txtSplit.Enabled = false;
            this.txtSplit.Location = new System.Drawing.Point(191, 14);
            this.txtSplit.Name = "txtSplit";
            this.txtSplit.Size = new System.Drawing.Size(100, 20);
            this.txtSplit.TabIndex = 7;
            this.txtSplit.Text = "Header 1";
            // 
            // chkSplit
            // 
            this.chkSplit.AutoSize = true;
            this.chkSplit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.chkSplit.Location = new System.Drawing.Point(15, 16);
            this.chkSplit.Name = "chkSplit";
            this.chkSplit.Size = new System.Drawing.Size(89, 17);
            this.chkSplit.TabIndex = 6;
            this.chkSplit.Tag = "split_on_style";
            this.chkSplit.Text = "split_on_style";
            this.chkSplit.UseVisualStyleBackColor = true;
            this.chkSplit.CheckedChanged += new System.EventHandler(this.chkSplit_CheckedChanged);
            // 
            // cmdConvertToPDF
            // 
            this.cmdConvertToPDF.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdConvertToPDF.Location = new System.Drawing.Point(15, 158);
            this.cmdConvertToPDF.Name = "cmdConvertToPDF";
            this.cmdConvertToPDF.Size = new System.Drawing.Size(160, 23);
            this.cmdConvertToPDF.TabIndex = 5;
            this.cmdConvertToPDF.Tag = "convert_to_pdf";
            this.cmdConvertToPDF.Text = "convert_to_pdf";
            this.cmdConvertToPDF.UseVisualStyleBackColor = true;
            this.cmdConvertToPDF.Click += new System.EventHandler(this.cmdConvertToPDF_Click);
            // 
            // documentsDropDownForPDF
            // 
            this.documentsDropDownForPDF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.documentsDropDownForPDF.Location = new System.Drawing.Point(188, 87);
            this.documentsDropDownForPDF.Name = "documentsDropDownForPDF";
            this.documentsDropDownForPDF.Size = new System.Drawing.Size(465, 28);
            this.documentsDropDownForPDF.TabIndex = 11;
            // 
            // tabStatistics
            // 
            this.tabStatistics.Controls.Add(this.chkGroups);
            this.tabStatistics.Controls.Add(this.label3);
            this.tabStatistics.Controls.Add(this.lstGroups);
            this.tabStatistics.Controls.Add(this.label2);
            this.tabStatistics.Controls.Add(this.lstColumns);
            this.tabStatistics.Controls.Add(this.lblColumns);
            this.tabStatistics.Controls.Add(this.chkGenerateAllAttempts);
            this.tabStatistics.Controls.Add(this.label1);
            this.tabStatistics.Controls.Add(this.chkOpenExcelFilesAfterConversion);
            this.tabStatistics.Controls.Add(this.chkStatisticsCreateSubFolder);
            this.tabStatistics.Controls.Add(this.chkCalculateExerciseStudentDetails);
            this.tabStatistics.Controls.Add(this.chkCalculateResultsPerStudent);
            this.tabStatistics.Controls.Add(this.lblTreeStat03);
            this.tabStatistics.Controls.Add(this.lblTreeStat02);
            this.tabStatistics.Controls.Add(this.chkCalculatePercentageMC);
            this.tabStatistics.Controls.Add(this.chkCPMCShowQuestionTitles);
            this.tabStatistics.Controls.Add(this.txtDoNotKnow);
            this.tabStatistics.Controls.Add(this.lblDoNotKnow);
            this.tabStatistics.Controls.Add(this.cmdDownloadStatistics);
            this.tabStatistics.Location = new System.Drawing.Point(4, 22);
            this.tabStatistics.Name = "tabStatistics";
            this.tabStatistics.Size = new System.Drawing.Size(759, 364);
            this.tabStatistics.TabIndex = 3;
            this.tabStatistics.Tag = "statistics";
            this.tabStatistics.Text = "statistics";
            this.tabStatistics.UseVisualStyleBackColor = true;
            this.tabStatistics.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tabStatistics_MouseMove);
            // 
            // chkGroups
            // 
            this.chkGroups.AutoSize = true;
            this.chkGroups.Location = new System.Drawing.Point(275, 51);
            this.chkGroups.Name = "chkGroups";
            this.chkGroups.Size = new System.Drawing.Size(58, 17);
            this.chkGroups.TabIndex = 69;
            this.chkGroups.Tag = "groups :";
            this.chkGroups.Text = "groups";
            this.chkGroups.UseVisualStyleBackColor = true;
            this.chkGroups.CheckedChanged += new System.EventHandler(this.chkGroups_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Image = global::lmsda.Properties.Resources.tree_corner;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(259, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(10, 13);
            this.label3.TabIndex = 68;
            this.label3.Text = " ";
            // 
            // lstGroups
            // 
            this.lstGroups.AllowDrop = true;
            this.lstGroups.AllowReorder = true;
            this.lstGroups.CheckBoxes = true;
            this.lstGroups.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstGroups.LineColor = System.Drawing.Color.Blue;
            this.lstGroups.Location = new System.Drawing.Point(275, 68);
            this.lstGroups.Name = "lstGroups";
            this.lstGroups.Size = new System.Drawing.Size(218, 98);
            this.lstGroups.TabIndex = 66;
            this.lstGroups.UseCompatibleStateImageBehavior = false;
            this.lstGroups.View = System.Windows.Forms.View.Details;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = global::lmsda.Properties.Resources.tree_corner;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(27, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 65;
            this.label2.Text = " ";
            // 
            // lstColumns
            // 
            this.lstColumns.AllowDrop = true;
            this.lstColumns.AllowReorder = true;
            this.lstColumns.CheckBoxes = true;
            this.lstColumns.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstColumns.LineColor = System.Drawing.Color.Blue;
            this.lstColumns.Location = new System.Drawing.Point(46, 68);
            this.lstColumns.Name = "lstColumns";
            this.lstColumns.Size = new System.Drawing.Size(193, 98);
            this.lstColumns.TabIndex = 64;
            this.lstColumns.UseCompatibleStateImageBehavior = false;
            this.lstColumns.View = System.Windows.Forms.View.Details;
            // 
            // lblColumns
            // 
            this.lblColumns.AutoSize = true;
            this.lblColumns.Location = new System.Drawing.Point(43, 52);
            this.lblColumns.Name = "lblColumns";
            this.lblColumns.Size = new System.Drawing.Size(86, 13);
            this.lblColumns.TabIndex = 52;
            this.lblColumns.Tag = "include_columns :";
            this.lblColumns.Text = "include_columns";
            // 
            // chkGenerateAllAttempts
            // 
            this.chkGenerateAllAttempts.AutoSize = true;
            this.chkGenerateAllAttempts.Location = new System.Drawing.Point(46, 30);
            this.chkGenerateAllAttempts.Name = "chkGenerateAllAttempts";
            this.chkGenerateAllAttempts.Size = new System.Drawing.Size(82, 17);
            this.chkGenerateAllAttempts.TabIndex = 50;
            this.chkGenerateAllAttempts.Tag = "all_attempts";
            this.chkGenerateAllAttempts.Text = "all_attempts";
            this.chkGenerateAllAttempts.UseVisualStyleBackColor = true;
            this.chkGenerateAllAttempts.CheckedChanged += new System.EventHandler(this.chkGenerateAllAttempts_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Image = global::lmsda.Properties.Resources.tree_corner;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(10, 13);
            this.label1.TabIndex = 49;
            this.label1.Text = " ";
            // 
            // chkOpenExcelFilesAfterConversion
            // 
            this.chkOpenExcelFilesAfterConversion.AutoSize = true;
            this.chkOpenExcelFilesAfterConversion.Location = new System.Drawing.Point(8, 308);
            this.chkOpenExcelFilesAfterConversion.Name = "chkOpenExcelFilesAfterConversion";
            this.chkOpenExcelFilesAfterConversion.Size = new System.Drawing.Size(190, 17);
            this.chkOpenExcelFilesAfterConversion.TabIndex = 48;
            this.chkOpenExcelFilesAfterConversion.Tag = "open_excel_files_after_conversion";
            this.chkOpenExcelFilesAfterConversion.Text = "open_excel_files_after_conversion";
            this.chkOpenExcelFilesAfterConversion.UseVisualStyleBackColor = true;
            this.chkOpenExcelFilesAfterConversion.CheckedChanged += new System.EventHandler(this.chkOpenExcelFilesAfterConversion_CheckedChanged);
            // 
            // chkStatisticsCreateSubFolder
            // 
            this.chkStatisticsCreateSubFolder.AutoSize = true;
            this.chkStatisticsCreateSubFolder.Checked = true;
            this.chkStatisticsCreateSubFolder.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStatisticsCreateSubFolder.Location = new System.Drawing.Point(8, 285);
            this.chkStatisticsCreateSubFolder.Name = "chkStatisticsCreateSubFolder";
            this.chkStatisticsCreateSubFolder.Size = new System.Drawing.Size(111, 17);
            this.chkStatisticsCreateSubFolder.TabIndex = 6;
            this.chkStatisticsCreateSubFolder.Tag = "create_sub_folder";
            this.chkStatisticsCreateSubFolder.Text = "create_sub_folder";
            this.chkStatisticsCreateSubFolder.UseVisualStyleBackColor = true;
            this.chkStatisticsCreateSubFolder.CheckedChanged += new System.EventHandler(this.chkStatisticsCreateSubFolder_CheckedChanged);
            // 
            // chkCalculateExerciseStudentDetails
            // 
            this.chkCalculateExerciseStudentDetails.AutoSize = true;
            this.chkCalculateExerciseStudentDetails.Location = new System.Drawing.Point(8, 175);
            this.chkCalculateExerciseStudentDetails.Name = "chkCalculateExerciseStudentDetails";
            this.chkCalculateExerciseStudentDetails.Size = new System.Drawing.Size(191, 17);
            this.chkCalculateExerciseStudentDetails.TabIndex = 12;
            this.chkCalculateExerciseStudentDetails.Tag = "calculate_exercise_student_details";
            this.chkCalculateExerciseStudentDetails.Text = "calculate_exercise_student_details";
            this.chkCalculateExerciseStudentDetails.UseVisualStyleBackColor = true;
            this.chkCalculateExerciseStudentDetails.CheckedChanged += new System.EventHandler(this.chkCalculateExerciseStudentDetails_CheckedChanged);
            // 
            // chkCalculateResultsPerStudent
            // 
            this.chkCalculateResultsPerStudent.AutoSize = true;
            this.chkCalculateResultsPerStudent.Checked = true;
            this.chkCalculateResultsPerStudent.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCalculateResultsPerStudent.Location = new System.Drawing.Point(8, 8);
            this.chkCalculateResultsPerStudent.Name = "chkCalculateResultsPerStudent";
            this.chkCalculateResultsPerStudent.Size = new System.Drawing.Size(167, 17);
            this.chkCalculateResultsPerStudent.TabIndex = 10;
            this.chkCalculateResultsPerStudent.Tag = "calculate_results_per_student";
            this.chkCalculateResultsPerStudent.Text = "calculate_results_per_student";
            this.chkCalculateResultsPerStudent.UseVisualStyleBackColor = true;
            this.chkCalculateResultsPerStudent.CheckedChanged += new System.EventHandler(this.chkCalculateResultsPerStudent_CheckedChanged);
            // 
            // lblTreeStat03
            // 
            this.lblTreeStat03.AutoSize = true;
            this.lblTreeStat03.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeStat03.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeStat03.Location = new System.Drawing.Point(27, 254);
            this.lblTreeStat03.Name = "lblTreeStat03";
            this.lblTreeStat03.Size = new System.Drawing.Size(10, 13);
            this.lblTreeStat03.TabIndex = 37;
            this.lblTreeStat03.Text = " ";
            // 
            // lblTreeStat02
            // 
            this.lblTreeStat02.AutoSize = true;
            this.lblTreeStat02.Image = global::lmsda.Properties.Resources.tree_corner;
            this.lblTreeStat02.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTreeStat02.Location = new System.Drawing.Point(27, 231);
            this.lblTreeStat02.Name = "lblTreeStat02";
            this.lblTreeStat02.Size = new System.Drawing.Size(10, 13);
            this.lblTreeStat02.TabIndex = 36;
            this.lblTreeStat02.Text = " ";
            // 
            // chkCalculatePercentageMC
            // 
            this.chkCalculatePercentageMC.AutoSize = true;
            this.chkCalculatePercentageMC.BackColor = System.Drawing.Color.Transparent;
            this.chkCalculatePercentageMC.Location = new System.Drawing.Point(8, 207);
            this.chkCalculatePercentageMC.Name = "chkCalculatePercentageMC";
            this.chkCalculatePercentageMC.Size = new System.Drawing.Size(149, 17);
            this.chkCalculatePercentageMC.TabIndex = 7;
            this.chkCalculatePercentageMC.Tag = "calculate_percentage_mc";
            this.chkCalculatePercentageMC.Text = "calculate_percentage_mc";
            this.chkCalculatePercentageMC.UseVisualStyleBackColor = false;
            this.chkCalculatePercentageMC.CheckedChanged += new System.EventHandler(this.chkCalculatePercentageMC_CheckedChanged);
            // 
            // chkCPMCShowQuestionTitles
            // 
            this.chkCPMCShowQuestionTitles.AutoSize = true;
            this.chkCPMCShowQuestionTitles.Enabled = false;
            this.chkCPMCShowQuestionTitles.Location = new System.Drawing.Point(46, 230);
            this.chkCPMCShowQuestionTitles.Name = "chkCPMCShowQuestionTitles";
            this.chkCPMCShowQuestionTitles.Size = new System.Drawing.Size(124, 17);
            this.chkCPMCShowQuestionTitles.TabIndex = 8;
            this.chkCPMCShowQuestionTitles.Tag = "show_question_titles";
            this.chkCPMCShowQuestionTitles.Text = "show_question_titles";
            this.chkCPMCShowQuestionTitles.UseVisualStyleBackColor = true;
            this.chkCPMCShowQuestionTitles.CheckedChanged += new System.EventHandler(this.chkCPMCShowQuestionTitles_CheckedChanged);
            // 
            // txtDoNotKnow
            // 
            this.txtDoNotKnow.Location = new System.Drawing.Point(225, 251);
            this.txtDoNotKnow.Name = "txtDoNotKnow";
            this.txtDoNotKnow.Size = new System.Drawing.Size(200, 20);
            this.txtDoNotKnow.TabIndex = 9;
            this.txtDoNotKnow.Text = "Don\'t know";
            // 
            // lblDoNotKnow
            // 
            this.lblDoNotKnow.AutoSize = true;
            this.lblDoNotKnow.Location = new System.Drawing.Point(43, 254);
            this.lblDoNotKnow.Name = "lblDoNotKnow";
            this.lblDoNotKnow.Size = new System.Drawing.Size(106, 13);
            this.lblDoNotKnow.TabIndex = 2;
            this.lblDoNotKnow.Tag = "do_not_know_label :";
            this.lblDoNotKnow.Text = "do_not_know_label :";
            // 
            // cmdDownloadStatistics
            // 
            this.cmdDownloadStatistics.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdDownloadStatistics.Location = new System.Drawing.Point(8, 331);
            this.cmdDownloadStatistics.Name = "cmdDownloadStatistics";
            this.cmdDownloadStatistics.Size = new System.Drawing.Size(158, 23);
            this.cmdDownloadStatistics.TabIndex = 5;
            this.cmdDownloadStatistics.Tag = "download_statistics";
            this.cmdDownloadStatistics.Text = "download_statistics";
            this.cmdDownloadStatistics.UseVisualStyleBackColor = true;
            this.cmdDownloadStatistics.Click += new System.EventHandler(this.cmdDownloadStatistics_Click);
            // 
            // tabSynchronization
            // 
            this.tabSynchronization.Controls.Add(this.tableLayoutStartSync);
            this.tabSynchronization.Controls.Add(this.progressBarSyncTotal);
            this.tabSynchronization.Controls.Add(this.subjectFilesSettingsControl);
            this.tabSynchronization.Location = new System.Drawing.Point(4, 22);
            this.tabSynchronization.Name = "tabSynchronization";
            this.tabSynchronization.Size = new System.Drawing.Size(759, 364);
            this.tabSynchronization.TabIndex = 5;
            this.tabSynchronization.Tag = "synchronization";
            this.tabSynchronization.Text = "synchronization";
            this.tabSynchronization.UseVisualStyleBackColor = true;
            this.tabSynchronization.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tabSynchronization_MouseMove);
            // 
            // tableLayoutStartSync
            // 
            this.tableLayoutStartSync.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutStartSync.ColumnCount = 2;
            this.tableLayoutStartSync.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48F));
            this.tableLayoutStartSync.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52F));
            this.tableLayoutStartSync.Controls.Add(this.lblSynchronisationStatus, 1, 0);
            this.tableLayoutStartSync.Controls.Add(this.pnlSyncButtons, 0, 0);
            this.tableLayoutStartSync.Location = new System.Drawing.Point(3, 298);
            this.tableLayoutStartSync.Name = "tableLayoutStartSync";
            this.tableLayoutStartSync.RowCount = 1;
            this.tableLayoutStartSync.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutStartSync.Size = new System.Drawing.Size(753, 37);
            this.tableLayoutStartSync.TabIndex = 35;
            // 
            // lblSynchronisationStatus
            // 
            this.lblSynchronisationStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSynchronisationStatus.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSynchronisationStatus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSynchronisationStatus.Location = new System.Drawing.Point(364, 3);
            this.lblSynchronisationStatus.Margin = new System.Windows.Forms.Padding(3);
            this.lblSynchronisationStatus.Name = "lblSynchronisationStatus";
            this.lblSynchronisationStatus.Size = new System.Drawing.Size(386, 31);
            this.lblSynchronisationStatus.TabIndex = 31;
            this.lblSynchronisationStatus.Text = "sync_status";
            this.lblSynchronisationStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlSyncButtons
            // 
            this.pnlSyncButtons.Controls.Add(this.cmdStartSynchronization);
            this.pnlSyncButtons.Controls.Add(this.cmdStopSynchronization);
            this.pnlSyncButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSyncButtons.Location = new System.Drawing.Point(3, 3);
            this.pnlSyncButtons.Name = "pnlSyncButtons";
            this.pnlSyncButtons.Padding = new System.Windows.Forms.Padding(5, 1, 5, 1);
            this.pnlSyncButtons.Size = new System.Drawing.Size(355, 31);
            this.pnlSyncButtons.TabIndex = 32;
            this.pnlSyncButtons.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlSyncButtons_MouseMove);
            // 
            // cmdStartSynchronization
            // 
            this.cmdStartSynchronization.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdStartSynchronization.Location = new System.Drawing.Point(6, 4);
            this.cmdStartSynchronization.Name = "cmdStartSynchronization";
            this.cmdStartSynchronization.Size = new System.Drawing.Size(344, 26);
            this.cmdStartSynchronization.TabIndex = 33;
            this.cmdStartSynchronization.Tag = "start_synchronization";
            this.cmdStartSynchronization.Text = "start_synchronization";
            this.cmdStartSynchronization.UseVisualStyleBackColor = true;
            this.cmdStartSynchronization.Click += new System.EventHandler(this.cmdStartSynchronization_Click);
            // 
            // cmdStopSynchronization
            // 
            this.cmdStopSynchronization.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdStopSynchronization.Location = new System.Drawing.Point(5, 4);
            this.cmdStopSynchronization.Name = "cmdStopSynchronization";
            this.cmdStopSynchronization.Size = new System.Drawing.Size(345, 28);
            this.cmdStopSynchronization.TabIndex = 34;
            this.cmdStopSynchronization.Tag = "stop_synchronization";
            this.cmdStopSynchronization.Text = "stop_synchronization";
            this.cmdStopSynchronization.UseVisualStyleBackColor = true;
            this.cmdStopSynchronization.Visible = false;
            this.cmdStopSynchronization.Click += new System.EventHandler(this.cmdStopSynchronization_Click);
            // 
            // progressBarSyncTotal
            // 
            this.progressBarSyncTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarSyncTotal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.progressBarSyncTotal.Location = new System.Drawing.Point(8, 339);
            this.progressBarSyncTotal.Name = "progressBarSyncTotal";
            this.progressBarSyncTotal.Size = new System.Drawing.Size(746, 10);
            this.progressBarSyncTotal.TabIndex = 32;
            // 
            // subjectFilesSettingsControl
            // 
            this.subjectFilesSettingsControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.subjectFilesSettingsControl.Location = new System.Drawing.Point(4, 4);
            this.subjectFilesSettingsControl.Margin = new System.Windows.Forms.Padding(0);
            this.subjectFilesSettingsControl.Name = "subjectFilesSettingsControl";
            this.subjectFilesSettingsControl.Size = new System.Drawing.Size(750, 298);
            this.subjectFilesSettingsControl.TabIndex = 0;
            // 
            // cmdChooseDocument
            // 
            this.cmdChooseDocument.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cmdChooseDocument.Location = new System.Drawing.Point(5, 12);
            this.cmdChooseDocument.Name = "cmdChooseDocument";
            this.cmdChooseDocument.Size = new System.Drawing.Size(121, 23);
            this.cmdChooseDocument.TabIndex = 3;
            this.cmdChooseDocument.Tag = "select_document";
            this.cmdChooseDocument.Text = "select_document";
            this.cmdChooseDocument.UseVisualStyleBackColor = true;
            this.cmdChooseDocument.Click += new System.EventHandler(this.cmdChooseDocument_Click);
            this.cmdChooseDocument.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdChooseDocument_MouseDown);
            // 
            // grbDocument
            // 
            this.grbDocument.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grbDocument.Controls.Add(this.lblDocumentSelected);
            this.grbDocument.Controls.Add(this.cmdChooseDocument);
            this.grbDocument.Location = new System.Drawing.Point(13, 74);
            this.grbDocument.Name = "grbDocument";
            this.grbDocument.Size = new System.Drawing.Size(768, 41);
            this.grbDocument.TabIndex = 17;
            this.grbDocument.TabStop = false;
            // 
            // lblDocumentSelected
            // 
            this.lblDocumentSelected.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDocumentSelected.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDocumentSelected.Location = new System.Drawing.Point(132, 16);
            this.lblDocumentSelected.Name = "lblDocumentSelected";
            this.lblDocumentSelected.Size = new System.Drawing.Size(629, 18);
            this.lblDocumentSelected.TabIndex = 18;
            this.lblDocumentSelected.Text = "No document selected";
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(61, 4);
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblStatus.Location = new System.Drawing.Point(-3, 523);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(94, 20);
            this.lblStatus.TabIndex = 18;
            this.lblStatus.Tag = "ready";
            this.lblStatus.Text = "Gereed";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStatus.DoubleClick += new System.EventHandler(this.lblStatus_DoubleClick);
            // 
            // ContainerFrame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 543);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.grbDocument);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.grbLogin);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.menuBar);
            this.Icon = global::lmsda.Properties.Resources.lmsda_icon;
            this.MainMenuStrip = this.menuBar;
            this.MinimumSize = new System.Drawing.Size(800, 570);
            this.Name = "ContainerFrame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ContainerFrame_FormClosing);
            this.Load += new System.EventHandler(this.ContainerFrame_Load);
            this.Shown += new System.EventHandler(this.ContainerFrame_Shown);
            this.grbLogin.ResumeLayout(false);
            this.grbLogin.PerformLayout();
            this.menuBar.ResumeLayout(false);
            this.menuBar.PerformLayout();
            this.tabs.ResumeLayout(false);
            this.tabExercises.ResumeLayout(false);
            this.tabExercises.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrRandomQuestions)).EndInit();
            this.tabPDF.ResumeLayout(false);
            this.tabPDF.PerformLayout();
            this.tabStatistics.ResumeLayout(false);
            this.tabStatistics.PerformLayout();
            this.tabSynchronization.ResumeLayout(false);
            this.tableLayoutStartSync.ResumeLayout(false);
            this.pnlSyncButtons.ResumeLayout(false);
            this.grbDocument.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.TextBox txtExerciseDump;
        private System.Windows.Forms.Button cmdScanDocument;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.GroupBox grbLogin;
        private System.Windows.Forms.Label lblInformation;
        private System.Windows.Forms.Button cmdLogin;
        private System.Windows.Forms.MenuStrip menuBar;
        private System.Windows.Forms.ToolStripMenuItem editMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem preferencesToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmbCourses;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tabExercises;
        private System.Windows.Forms.TabPage tabPDF;
        private System.Windows.Forms.Button cmdChooseDocument;
        private System.Windows.Forms.TextBox txtSplit;
        private System.Windows.Forms.CheckBox chkSplit;
        private System.Windows.Forms.Button cmdConvertToPDF;
        private System.Windows.Forms.ToolStripMenuItem actionsMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.GroupBox grbDocument;
        private System.Windows.Forms.Label lblDocumentSelected;
        private System.Windows.Forms.Button cmdUploadExercises;
        private System.Windows.Forms.CheckBox chkUpload;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.Button cmdLogout;
        private DocumentsDropDown documentsDropDownForPDF;
        private System.Windows.Forms.RadioButton rdbPerPage;
        private System.Windows.Forms.RadioButton rdbPerStyle;
        private System.Windows.Forms.Label lblTreePdf02;
        private System.Windows.Forms.Label lblTreePdf01;
        private System.Windows.Forms.TabPage tabStatistics;
        private System.Windows.Forms.Button cmdDownloadStatistics;
        private System.Windows.Forms.Button cmdReviewExercises;
        private System.Windows.Forms.CheckBox chkCalculatePercentageMC;
        private System.Windows.Forms.CheckBox chkCPMCShowQuestionTitles;
        private System.Windows.Forms.TextBox txtDoNotKnow;
        private System.Windows.Forms.Label lblDoNotKnow;
        private System.Windows.Forms.Label lblTreeStat02;
        private System.Windows.Forms.Label lblTreeStat03;
        private System.Windows.Forms.CheckBox chkCalculateResultsPerStudent;
        private System.Windows.Forms.CheckBox chkCalculateExerciseStudentDetails;
        private System.Windows.Forms.Button cmdJumpToError;
        private System.Windows.Forms.CheckBox chkStatisticsCreateSubFolder;
        private System.Windows.Forms.CheckBox chkOneQuestionPerPage;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TabPage tabSynchronization;
        private System.Windows.Forms.Button cmdStartSynchronization;
        private System.Windows.Forms.ProgressBar progressBarSyncTotal;
        private System.Windows.Forms.Label lblSynchronisationStatus;
        private subject.SubjectFilesSettingsControl subjectFilesSettingsControl;
        private System.Windows.Forms.ToolStripMenuItem manageSubjectsToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkConvertHyperlinksToJavascript;
        private System.Windows.Forms.Button cmdOpenTemplate;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkOpenExcelFilesAfterConversion;
        private System.Windows.Forms.Label lblTreeEx01;
        private System.Windows.Forms.CheckBox chkNewDocWithExamples;
        private System.Windows.Forms.Label lblTreeEx02;
        private System.Windows.Forms.Label lblExerciseScanResults;
        private System.Windows.Forms.Label lblExerciseErrors;
        private System.Windows.Forms.Label lblExerciseScanResultsDump;
        private System.Windows.Forms.Button cmdStopSynchronization;
        private System.Windows.Forms.CheckBox chkSetExerciseInvisible;
        private System.Windows.Forms.ToolStripMenuItem checkforupdatesToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutStartSync;
        private System.Windows.Forms.Panel pnlSyncButtons;
        private System.Windows.Forms.NumericUpDown nrRandomQuestions;
        private System.Windows.Forms.CheckBox chkRandomQuestions;
        private System.Windows.Forms.Label lblTreeEx04;
        private System.Windows.Forms.Label lblTreeEx03;
        private System.Windows.Forms.ToolStripSeparator aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadfilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewlogToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator tToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkGenerateAllAttempts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblColumns;
        private listview.DragAndDropListView lstColumns;
        private System.Windows.Forms.Label label2;
        private listview.DragAndDropListView lstGroups;
        private System.Windows.Forms.CheckBox chkGroups;
        private System.Windows.Forms.Label label3;
    }
}